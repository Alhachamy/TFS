
package GUI;
//‘******************************************************
//‘*** Class Name: HowToUse
//‘*** Class Author: Back Row Mafia
//‘******************************************************
//‘*** Purpose: JPANEL THAT SHOW how to use the program
//‘***
//‘******************************************************
//‘*** Date: 12/1/2018
//‘******************************************************
public class HowToUse extends javax.swing.JPanel {

    public HowToUse() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.white, java.awt.Color.black));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setText("HOW TO USE PROGRAM");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setText("Welcome to the Traffic Simulator!\n\nHow to Use:\n1) After you load an OSM map and Input a number of vehicles, the simulation\nwill begin.\n2) After the simulation beings, you will have access to a menu bar, which\nwill be located at the very top of the program. The menu bar has various\noptions.\n\nA) \"File\" : this menu option allows you to exit the program through the \"exit\"\noption.\nB) \"Clock\" : this menu option allows you to view the current time through\nthe \"View Clock\" submenu. the Clock allows you to view and modify the\nclock in real time.\nC) \"Car\" : this menu option displays vehicle details such as speed and \nroad, it also allows you to crash a vehicle.\nD) \"Help\" : this menu option contains two submenu options, \"About\" and \"How\nto Use\". The \"About\" option displays software version. The \"How to Use\" option\nleads to this window.\n\nProgram Requirments:\n1) In order to use this program, you need an exported map from \nOpenStreetMaps, an \"OSM\" file.\n2) If you do not enter a valid vehicle number when you start the program, it will\nexit and you will need to restart.");
        jTextArea1.setBorder(null);
        jTextArea1.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jTextArea1.setEnabled(false);
        jTextArea1.setFocusable(false);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(jLabel1)
                .addContainerGap(116, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
