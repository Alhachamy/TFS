package GUI;

import javax.swing.JSplitPane;
//‘******************************************************
//‘*** Class Name: Splitter
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this class is responsible for displaying the streetpanel
//‘*** along side the menu bar
//‘******************************************************

public class Splitter extends JSplitPane implements Runnable 
{
    // INIT THREAD
    private Thread threading;
    // INIT LAYER OBJECT
    private final Layers LR;
    // INIT STREET PANEL
    private final StreetPanel SP;
    // INIT CLOCK
    private final Time clock;
    // INIT CAR DETAILS
    private final CarDetails CD;
    // CONSTRUCTOR
    public Splitter(StreetPanel SP, Layers LR) 
    {
        // SET SPLIT PROPERTY
        super(JSplitPane.HORIZONTAL_SPLIT);
        // SET LEFT COMPONENT TOTHE TRAFFIC PANEL
        this.setLeftComponent(SP);
        // REMOVE DIVIDER
        this.setDividerSize(1);
        // INIT CAR DETAILS
        this.CD = new CarDetails();
        // PASS CAR DETAILS FROM HERE TO STREET PANEL
        SP.setCD(this.CD);
        // PASS CAR DETAILS TO LAYERS
        LR.setCD(this.CD);
        // INIT LAYER
        LR.init();
        // SET THIS LAYER TO THE ONE PASSED
        this.LR = LR;
        // SET THIS STREET PANEL TO THE ONE PASSED
        this.SP = SP;
        // INIT TIME
        clock = new Time();
    }
    
    @Override
//‘******************************************************
//‘*** Method Name: addNotify
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: this is a default java method
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    public void addNotify(){
        // CALL SUPER
        super.addNotify();
        // SET THREAD
        threading = new Thread(this);
        // NAME IT
        threading.setName("FRAME");
        // START THREADING
        threading.start();
    }
    
    @Override
//‘******************************************************
//‘*** Method Name: run
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: runnable method for threading
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    public void run() {
        // INIT CONSTANTS
        long beforeTime, timeDiff, sleep;
        // INIT OLD TIME
        beforeTime = System.currentTimeMillis();
        
        // INFINITE LOOP
        while(true)
        {
            // UPDATE THE STREET PANEL
            SP.repaint();
            // CHECK LAYERS
            if(LR.isOn()){
                // UPDATE CARS
                CD.update();
                // UPDATE STREET PANEL LAYERS
                SP.update(LR.getIntFastForward());
                // UPDATE CLOCK
                LR.setClock(clock.tick(LR.getIntFastForward()));
                // UPDATE DAY
                LR.setDay(clock.getDay());
            }
            // SET NEW TIME
            timeDiff = System.currentTimeMillis() - beforeTime;
            // SET SLEEP TIME
            sleep = 125 - timeDiff;
            // COMPARE SLEEP
            if(sleep < 0){
                // SET NEW SLEEP IF 0
                sleep = 2;
            }
            // WAIT THREAD
            try{
                Thread.sleep(sleep);
                // CATCH ERROR
            }catch(InterruptedException ex){}
            // SET BEFORE TIME
            beforeTime = System.currentTimeMillis();
        }
    }
    // GETTER
    // GET CAR
    public CarDetails getCar(){
        return this.CD;
    }
}
