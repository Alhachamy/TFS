package GUI;

import Cars.Bus;
import Cars.Car;
import Cars.Logic;
import Cars.Sedan;
import Graphics.JavaGraphs;
import OsmParser.ReadFile;
import Storage.DB;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.util.Random;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

//‘******************************************************
//‘*** Class Name: TrafficSimulator
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this is the main gui class, everything will be initilized here
//‘*** and jframes will start here
//‘******************************************************

public class TrafficSimulator {
    // INIT OBJECTS
    private static JavaGraphs regraph;
    private static DB database;
    private static JMenuBar menuBar;
    private static ClockWindow cw;
    private static CarDetails cd;
    private static About ab;
    private static HowToUse htu;
    private static String dir;
    private static int cars;
    
    // MAIN METHOD
    public static void main(String[] args) {
        // JUST CALLS INIT FUNCTION
        init();
    }
    
//‘******************************************************
//‘*** Method Name: menuInit
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: this method creates the top menu bar in the gui
//‘*** Method Inputs:  none
//‘*** parameters: none 
//‘*** Return value: void
//‘******************************************************


    public static void menuInit(){
        // CREATE MENUBAR
        menuBar = new JMenuBar();
        // SET ITS COLOR
        menuBar.setBackground(Color.WHITE);
        // SET BORDER
        menuBar.setBorderPainted(true);
        // CREATE MENU ITEMS
        JMenu file = new JMenu("File");
        JMenu clock = new JMenu("Clock");
        JMenu vehicle = new JMenu("Car");
        JMenu help = new JMenu("Help");
        // ADD MENU ITEMS TO JMENU
        menuBar.add(file);
        menuBar.add(clock);
        menuBar.add(vehicle);
        menuBar.add(help);
        // CREATE SUB MENUS
        JMenuItem ext = new JMenuItem("Exit");
        JMenuItem time = new JMenuItem("View Clock");
        JMenuItem car = new JMenuItem("Vehicle Details");
        JMenuItem about = new JMenuItem("About");
        JMenuItem howTo = new JMenuItem("How To Use");
        
        // ACTION EVENT FOR EXIT SUB MENU
        ext.addActionListener((ActionEvent e) -> {
            // CLOSE PROGRAM
            System.exit(0);
        });
        // ACTION EVENT FOR TIME SUB MENU
        time.addActionListener((ActionEvent e) -> {
            // CREATE JFRAME
            JFrame f = new JFrame("Timer");
            f.setPreferredSize(new java.awt.Dimension(310,230));
            // ADD CLOCK TO IT
            f.add(cw);
            // SET SOME PROPERTIES
            f.setResizable(false);
            f.setUndecorated(true);
            f.setAlwaysOnTop(true);
            f.pack();
            // MAKE IT VISIBLE
            f.setVisible(true);
        });
        
        // ACTION EVENT FOR CAR SUB MENU ITEM
        car.addActionListener((ActionEvent e) -> {
            // CREATE JFRAME
            JFrame f = new JFrame("Car");
            // SET ITS PROPERTIES
            f.setSize(400,250);
            f.setResizable(false);
            f.setUndecorated(true);
            f.setFocusable(true);
            f.setAlwaysOnTop(true);
            // ADD CAR DETAILS JPANEL
            f.add(cd);
            f.pack();
            // SET VISIBLE
            f.setVisible(true);
        });
            // ACTION EVENT FOR ABOUT JPANEL
            about.addActionListener((ActionEvent e) -> {
            // INIT JPANEL
            ab = new About();
            // INIT JFRAME
            JFrame f = new JFrame("About");
            // INIT ITS PROPERTIES
            f.setSize(400,250);
            f.setResizable(false);
            f.setFocusable(true);
            f.setAlwaysOnTop(true);
            // ADD JPANEL TO JFRAME
            f.add(ab);
            f.pack();
            // SET VISIBLE
            f.setVisible(true);
        });
            // ACTION EVENT FOR HOW TO JPANEL
            howTo.addActionListener((ActionEvent e) -> {
            // INIT JPANEL
            htu = new HowToUse();
            // INIT JFRAME
            JFrame f = new JFrame("How To Use");
            // SET ITS PROPERTIES
            f.setSize(400,250);
            f.setResizable(false);
            f.setFocusable(true);
            f.setAlwaysOnTop(true);
            // ADD JPANEL TO JFRAME
            f.add(htu);
            f.pack();
            // SET VISIBLE
            f.setVisible(true);
        });
        // ADD ALL THE ITEMS TO THE MENU
        file.add(ext);
        clock.add(time);
        vehicle.add(car);
        help.add(about);
        help.add(howTo); 
    }
    
//‘******************************************************
//‘*** Method Name: init
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method that initilizes the the street panel
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************


    private static void init() {
        // CREATE JFRAME
        JFrame frame = new JFrame("Traffic Simulator");
        // SET PROPERTIES
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(true);
        // CALL THE LOAD MAP FUNCTION
        loadMap();
        // CALL READ FILE METHOD
        readFile();
        // CALL CREATE VEHICLES METHOD
        CreateVehicles();
        // INIT REGRAPH AND PASS IT THE DATABASE
        regraph = new JavaGraphs(database);
        // INIT STREET PANEL AND PASS IT REGRAPH AND DATABASE
        StreetPanel SP = new StreetPanel(regraph,database);
        // INIT LAYERS
        Layers layers = new Layers();
        // INIT SPLITTER AND PASS IT STREET PANEL AND LAYERS
        Splitter s = new Splitter(SP, layers);
        // CALL MENUINIT METHOD
        menuInit();
        // ADD THE MENUBAR TO THE FRAME
        frame.setJMenuBar(menuBar);
        // SET ITS PROPERTIES
        frame.setLayout(new BorderLayout());
        frame.setJMenuBar(menuBar);
        // PASS THE SPLITTER TO THE FRAME
        frame.add(s, BorderLayout.CENTER);
        // INIT CLOCKWINDOW
        cw = new ClockWindow();
        // INIT WATCH
        cw = layers.getWatch();
        // INIT CAR DETAILS
        cd = new CarDetails();
        // SET IT TO THE ONE IN LAYERS
        cd = layers.getCar();
        // PACK THE FRAME TO THE APPROPRIATE SIZE
        frame.pack();
        // DISPLAY FRAME
        frame.setVisible(true);    
    }
    
//‘******************************************************
//‘*** Method Name: readFile
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method to read osm map
//‘*** Method Inputs: none
//‘*** parameters: none 
//‘*** Return value: void
//‘******************************************************


    private static void readFile() {
        // CREATE DOCUMENT AND PASS IT A DIRECTORY
        ReadFile Doc = new ReadFile(dir);
        // RUN FILE METHOD
        Doc.MainCalculation();
        // PASS THE DOCUMENT FROM DATABASE
        database = Doc.getDatabase();
    }

//‘******************************************************
//‘*** Method Name: CreateVehicles
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: creates cars
//‘*** Method Inputs: none
//‘*** parameters: none 
//‘*** Return value: void
//‘******************************************************


    private static void CreateVehicles(){          
        // INIT AI OBJECT
        Logic ins;
        // INIT CAR OBJECT
        Car vehicle;
        // INIT RANDOM NUMBERS
        Random rand = new Random();
        // INIT INT
        int num = rand.nextInt(100);
        // ITERATE THROUGH CARS
        for(int i=0; i < cars; i++){
            // PASS LOGIC FROM DATABASE
            ins = new Logic(database);
            // COMPARE
            if(num > 20){
                // CREATE SEDAN
                vehicle = new Sedan(ins);
            }
            else{
                // CREATE BUSS
                vehicle = new Bus(ins);
            }
            // ADD CARS TO DB
            database.addVehicle(vehicle);
            // REINSTATE RAND
            num = rand.nextInt(100);
        }
    }
    
//‘******************************************************
//‘*** Method Name: loadMap
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: loads an osm map
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************


    private static void loadMap(){
        // TRY
        try{
            // CREATE JOPTION PANE
        JOptionPane.showMessageDialog(null ,"Welcome to Traffic Simulator!\nPress 'Ok' to continue!");
        // CREATE JFILE CHOOSER
        JFileChooser chooser = new JFileChooser();
        // SET OSM FILTER
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "OSM File", "osm");
            // ADD FILTERS
            chooser.setFileFilter(filter);
            // RETURN FLAG
            int returnVal = chooser.showOpenDialog(null);
            // IF VALID FILE IS CHOSEN
            if (returnVal == JFileChooser.APPROVE_OPTION) {
            // GET IT'S PATH
            dir = chooser.getSelectedFile().getPath();
            JOptionPane.showMessageDialog(null ,"Map Loaded!");
            } // OTHERWISE
            else{
                // PRINT ERROR
                JOptionPane.showMessageDialog(null ,"Operation Cancelled!");
                // CLOSE PROGRAM
                System.exit(0);
            }// OTHERWISE
        }catch(Exception e){
            // EXIT
            System.exit(0);
        }
        // TRY
        try{
            // PROMPT USER FOR CAR INPUT
            String val = JOptionPane.showInputDialog("Number of Cars:");
            // PARSE INTEGER
            cars = Integer.parseInt(val); 
            JOptionPane.showMessageDialog(null ,"Cars Added!");
       } // CATCH EXCEPTION
       catch(NumberFormatException e){
           // PRINT ERROR
            JOptionPane.showMessageDialog(null ,"Canceled/Invalid input, Exiting program!");
            // EXIT
            System.exit(0);
       }
    }
}
