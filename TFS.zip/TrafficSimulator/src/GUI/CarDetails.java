package GUI;

import Cars.Car;
import Storage.DB;
import java.util.ArrayList;

//‘******************************************************
//‘*** Class Name: CarDetails
//‘*** Class Author: Back Row Mafia
//‘******************************************************
//‘*** Purpose: JPanel that shows car speed, street, 
//‘*** and allows the user to crash it
//‘******************************************************
//‘*** Date: 12/1/2018
//‘******************************************************
public class CarDetails extends javax.swing.JPanel {
    // INIT CAR
    private int currentCar = -1;
    // INIT A CAR OBJECT
    private ArrayList<Car> vehicleList;
    // CONSTRUCTOR
    public CarDetails() {
        // SET CAR LIST TO THE ONE FROM THE DATABASE
        vehicleList = DB.getVehicleList();
        initComponents();
    }
    
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // SET SPEED
    public void setCarSpeed(String speed){
        this.lblSpeed.setText(speed);
    }
    // SET ROAD
    public void setCarCurrentRoad(String CCR){
        this.lblStreet.setText(CCR);
    }
    // SET CAR
    public void setCurrentvehicle(int vehicle){
        this.currentCar = vehicle;
    }
    // SET CAR INDEX
    public void setCurrentIndex(int index){
        this.currentCar = index;
    }
    

//‘******************************************************
//‘*** Method Name: update
//‘*** Method Author: Back Row Mafia
//‘******************************************************
//‘*** Purpose of the Method: method that updates values in database
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************
//‘*** Date 12/1/2018
//‘******************************************************

    public void update(){
        // MAKE SURE CAR ISNT NULL
        if(currentCar >=0){
          // UPDATE SPEED
          this.setCarSpeed(String.valueOf(DB.getVehicle(this.currentCar).getSpeed()));
          // UPDATE ROAD
          this.setCarCurrentRoad(DB.getVehicle(this.currentCar).getRoad().getName());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblSpeed = new javax.swing.JLabel();
        lblStreet = new javax.swing.JLabel();
        btnExit = new javax.swing.JButton();
        btnCrash = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.white, java.awt.Color.black));
        setAutoscrolls(true);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("CAR DETAILS");

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("SPEED:");

        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("STREET:");

        lblSpeed.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        lblSpeed.setForeground(new java.awt.Color(0, 0, 0));
        lblSpeed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSpeed.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        lblStreet.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        lblStreet.setForeground(new java.awt.Color(0, 0, 0));
        lblStreet.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStreet.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btnExit.setBackground(new java.awt.Color(255, 255, 255));
        btnExit.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnExit.setForeground(new java.awt.Color(0, 0, 0));
        btnExit.setText("EXIT");
        btnExit.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnExit.setFocusPainted(false);
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btnCrash.setBackground(new java.awt.Color(255, 255, 255));
        btnCrash.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnCrash.setForeground(new java.awt.Color(0, 0, 0));
        btnCrash.setText("CRASH CAR");
        btnCrash.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnCrash.setFocusPainted(false);
        btnCrash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrashActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblSpeed, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblStreet, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnCrash, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(lblSpeed, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(lblStreet, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(btnCrash)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnExit)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents
    // BUTTON CLICK TO EXIT
    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // EXIT FORM
        this.getRootPane().getParent().setVisible(false);
    }//GEN-LAST:event_btnExitActionPerformed
    // BUTTON CLICK TO CRASH CAR
    private void btnCrashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrashActionPerformed
       // CRASH CAR
       vehicleList.get(currentCar).setInAccident(true);
    }//GEN-LAST:event_btnCrashActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCrash;
    private javax.swing.JButton btnExit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lblSpeed;
    private javax.swing.JLabel lblStreet;
    // End of variables declaration//GEN-END:variables
}
