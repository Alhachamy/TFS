package GUI;

import javax.swing.JPanel;
//‘******************************************************
//‘*** Class Name: Layers
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this class inits all the different jpanels of the program
//‘***
//‘******************************************************

public class Layers extends JPanel
{ 
    // INIT CARDETAILS OBJECT
    private CarDetails CD;
    // INIT CARWINDOW OBJECT
    private ClockWindow CW;
    // CONSTRUCTOR    
    public Layers(){
        // CALL SUPER
        super();
    }    
    // INIT
    public void init(){  
        // SET NEW CLOCK WINDOW
        this.CW = new ClockWindow();
        // MAKE INVISIBLE
        this.setVisible(false);
    }
    // GETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // RETURN CLOCK
    public ClockWindow getWatch(){
        return this.CW;
    }
    // RETURN CAR
    public CarDetails getCar(){
        return this.CD;
    }
    
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // SET CARDETAILS
    public void setCD(CarDetails CD){
        this.CD = CD;
    }
    // SET CLOCK
    public void setClock(String time){
        this.CW.setClock(time);
    }
    // SET DAY
    public void setDay(String day){
        this.CW.setDay(day);
    }
    // SET BOOL FLAG
    public boolean isOn(){
        return this.CW.isOn();
    }
    // RETURN FASTFORWARD
    public int getIntFastForward(){
        return this.CW.getIntFastForward();
    }

}
