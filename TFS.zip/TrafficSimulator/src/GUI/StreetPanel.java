package GUI;

import Cars.Controller;
import Graphics.JavaGraphs;
import OsmParser.Scaling;
import Storage.DB;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.JPanel;
//‘******************************************************
//‘*** Class Name: StreetPanel
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this is the programs street panel,
//‘*** which is the main event
//‘******************************************************

public class StreetPanel extends JPanel{
    // INIT CHANGE IN X
    double chX;
    // INIT CHANGE IN Y
    double chY;
    // INIT DERIVATIVES
    double dx;
    double dy;
    // INIT SCALE FACTORS
    public int W = 10000;
    public int H = 9000;
    // INIT JAVAGRAPHS OPBJECT
    private JavaGraphs regraph;  
    // INIT SCAL
    private double scale = 0.20;
    // INIT DB OBJECT
    private final DB DB;
    // INIT CONTROL OBJECT
    private final Controller ctrl;
    // INIT CAR DETAILS OBJECT
    private CarDetails CD;
    // INIT SCALE FACTOR X
    private Scaling scaleX;
    // INIT SCALE FACTOR Y
    private Scaling scaleY;
    
    // CONSTRUCTOR
    public StreetPanel(JavaGraphs JG, DB DB){
        // CALL SUPER
        super();
        // SET FOCUS
        this.setFocusable(true);
        // REQUEST FOCUS
        requestFocus();
        // PASS GRAPH OBJECT
        this.regraph = JG;
        // SET CURSOR
        Cursor hand = new Cursor(Cursor.HAND_CURSOR);
        // SET CURSOR TYPE
        this.setCursor(hand);
        // SET BACKGROUND COLOR
        this.setBackground(Color.BLACK);
        // PASS CONTROLER
        this.ctrl = new Controller(DB);
        // PASS DATABASE
        this.DB = DB;
        // INIT MOUSE HANDLER
        MouseHandler mouseHandler = new MouseHandler();
        // SET MOUSE LISTENER PROPERTIES
        this.addMouseListener(mouseHandler);
        this.addMouseMotionListener(mouseHandler);
        this.addMouseWheelListener(mouseHandler);
        // SCALE MAP
        scaleRegion();
    }
    // SETTER
    // SET GRAPH
    public void setregraph(JavaGraphs p){
        // PASS OBJECT
        this.regraph = p;  
    }
    
//‘******************************************************
//‘*** Method Name: scaleRegion
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method sets the scaling of the jpanel by  
//‘*** taking the bounds and scaling it to the window
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void scaleRegion(){   
        // SET PARAMS
        // MAX LON, MIN LON, MAX Y LON, MIN Y LON
        scaleX = new Scaling(DB.getBounds(3), DB.getBounds(1), W, 0 );
        // SET PARAMS
        // MAX LAT, MIN LAT, MAX X LAT, MIN X LAT
        scaleY = new Scaling(DB.getBounds(2), DB.getBounds(0),H, 0 );
    }
    // SINCE THE Y VALUE IS NEGATIVE, THIS MAKES IT POSITIVE
    private double setPositive(double y){
        return -y + H;
    }
    
    @Override
//‘******************************************************
//‘*** Method Name: paintComponent
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: this is a default java method to draw graphics
//‘*** Method Inputs: none
//‘*** parameters: graphics g
//‘*** Return value: void
//‘******************************************************

    public void paintComponent(Graphics g)
    {
        // SET SCALE
        regraph.setScalar(scale);
        // PASS X AND Y
        regraph.setShiftXY(chX, chY);
        // PAINT
        super.paintComponent(g);
        // DRAW ROAD
        regraph.DrawRoad(g);
        // DRAW CAR
        regraph.DrawCar(g);
        // FREE UP MEMORY
        g.dispose();
    }
    // UPDATE METHOD
    public void update(int rate){
        // UPDATE CARS
        regraph.updateVehicles(rate);
    }
    // SET CAR DETAILS
    public void setCD(CarDetails CD){
        this.CD = CD;
    }
    
//‘******************************************************
//‘*** Class Name: MouseHandler
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this is a subclass that handlees mouse clicks in 
//‘*** the jaypanel
//‘******************************************************

    private class MouseHandler implements MouseListener, MouseMotionListener, MouseWheelListener{
        // INIT TEMP X
        int tempX = 0;
        // INIT TEMP Y
        int tempY =0;
        
        @Override
        
        //‘******************************************************
        //‘*** Method Name: mouseClicked
        //‘*** Method Author: Ali A
        //‘******************************************************
        //‘*** Purpose of the Method: default action event
        //‘*** Method Inputs: none
        //‘*** parameters: mouse event
        //‘*** Return value: void
        //‘******************************************************


        public void mouseClicked(MouseEvent e) {
            // IF MOUSE BUTTON IS CLICKED
            if(e.getButton() == MouseEvent.BUTTON1) {
                // GET POINT
                Point p = e.getPoint();
                // CALCULATE CURRENT CAR INDEX
                int carIndex = ctrl.find(scaleX.unScale((p.x/scale) - chX), 
                                         scaleY.unScale(setPositive((p.y/scale) - chY)));
                // SET THE CALCULATED INDEX TO CURRENT CAR INDEX
                CD.setCurrentIndex(carIndex);
            }
        }

        @Override
        // MOUSE EVENT
        public void mousePressed(MouseEvent e) {
            // SET DUMMY POINTS
            tempX = e.getX();
            tempY = e.getY();
        }
        @Override
        
        //‘******************************************************
        //‘*** Method Name: mouseDragged
        //‘*** Method Author: Ali A
        //‘******************************************************
        //‘*** Purpose of the Method: this method drags the jpanel around
        //‘*** Method Inputs: none
        //‘*** parameters: mouse event drag
        //‘*** Return value: none
        //‘******************************************************

        public void mouseDragged(MouseEvent e) {
            // SET DX TO TEMP
            dx = (e.getX() - tempX);
            // SET DY TEMP
            dy = (e.getY() - tempY);
            
            // COMPARE TO SCALE
            if(scale >= 1){
                // CHANGE LOCATION
                chX += dx*0.2;
                chY += dy*0.2;
            }// OTHERWISE
            else{
                // CHANGE LOCATION
                chX += dx*0.4;
                chY += dy*0.4;
            }
            // CALL REPAINT
            repaint();      
        }
        
        @Override
        
        //‘******************************************************
        //‘*** Method Name: mouseWheelMoved
        //‘*** Method Author: Ali A
        //‘******************************************************
        //‘*** Purpose of the Method: method to zoom in and out
        //‘*** Method Inputs: none 
        //‘*** parameters: mousewheel scroll
        //‘*** Return value: void
        //‘******************************************************


        public void mouseWheelMoved(MouseWheelEvent e) {
            // INIT MOUSE WHEEL ROTATION
            int wheelRot=e.getWheelRotation();
            // COMPARE ROTATION
            if(wheelRot < 0){
                // ZOOM IN
                scale += 0.05;
            } // OTHERWISE
            else if(wheelRot > 0){
                // ZOOM OUT
                scale -= 0.05;
                // COMPARE TO 0
                if(scale <= 0){
                    // SET IT TO A FIXED SCALE
                    scale = 0.20;
                }
            }  
            // REPAINT
            repaint();           
        }
        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
        // USELESS ABSTRACT FUNCTIONS, DON'T NEED TO IMPLEMENT THEM
        @Override
        public void mouseReleased(MouseEvent e){} 
        @Override
        public void mouseEntered(MouseEvent e) {}
        @Override
        public void mouseExited(MouseEvent e) {}
        @Override
        public void mouseMoved(MouseEvent e) {}
        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    }
    
}
