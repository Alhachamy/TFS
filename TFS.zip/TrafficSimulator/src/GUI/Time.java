
package GUI;

import java.util.Random;
//‘******************************************************
//‘*** Class Name: Time
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: the clock class creates a clock with time of day,
//‘*** and day of the week
//‘******************************************************

public class Time {
    // INIT DAY
    private int day;
    // INIT SECONDS
    private int seconds;
    // INIT MINUTES
    private int minutes;
    // INIT HOURS
    private int hours;
    // CONSTRUCTOR
    public Time(){
        // INIT RANDOM NUMBER
        Random rand = new Random();
        // SET DAY
        day = rand.nextInt(7);
        // SET HOURS
        hours = rand.nextInt(24);
        // SET MINUTES
        minutes = rand.nextInt(60);
        // SET SECONDS
        seconds = rand.nextInt(60);
    }

//‘******************************************************
//‘*** Method Name: tick
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method updates tickrate
//‘*** Method Inputs: none
//‘*** parameters: int
//‘*** Return value: String
//‘******************************************************

    public String tick(int rate){
        // SET SECONDS
        this.seconds += (1 * rate);
        // COMPARE SECONDS
        if(this.seconds >= 60){
            // CHANGE MINUTE
            changeM();
        }
        // RETURN DATE
        return this.getDate();
    }

//‘******************************************************
//‘*** Method Name: changeM
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: sets what minute it is in the current hour
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************


    private void changeM(){  
        // INIT MINUTES
        this.minutes += this.seconds / 60;
        // FIND THE REMAINDER OF THE SECONDS
        this.seconds %= 60;
        // COMPARE TO 60
        if(this.minutes >= 60){
            // CHANGE HOUR
            changeH();
        }
    }
 
//‘******************************************************
//‘*** Method Name: changeH
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: changes hour in current day
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************


    private void changeH(){
        // SET HOURS
        this.hours += this.minutes / 60;
        // FIND REMAINDER
        this.minutes %= 60;
        // COMPARE TO 24
        if(this.hours >= 24){
            // CHANGE DAY
            changeD();
        }
    }
 
//‘******************************************************
//‘*** Method Name: changeD
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: change current Day
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************


    private void changeD(){
        // INCREMENT DAY
        this.day ++;
        // FIND REMAINDER
        this.hours%= 24;
        // COMPARE TO 6 DAYS A WEEK
        if(this.day >= 6){
            this.day = 0 ;
        }
    }

//‘******************************************************
//‘*** Method Name: getDay
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: returns Day string
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************


    public String getDay(){
        // CLEAR STRING
        String dayStr = "";
        // SWITCH TO CHECK DAY AND SET THE STRING
        switch(this.day)
        {
            case(0):
                dayStr = "Monday";
                break;
            case(1):
                dayStr = "Tuesday";
                break;        
            case(2):
                dayStr = "Wednesday";
                break;            
            case(3):
                dayStr = "Thursday";
                break;
            case(4):
                dayStr = "Friday";
                break;
            case(5):
                dayStr = "Saturday";
                break;        
            case(6):
                dayStr = "Sunday";
                break;         
        }
        return dayStr;
    }
 
//‘******************************************************
//‘*** Method Name: getDate
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: returns clock string
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private String getDate(){
        // RETURN FORMATTED STRING
        return  String.format( " %02d ",this.hours) + 
                ": " + String.format( " %02d ",this.minutes) + 
                ": " + String.format( " %02d ",this.seconds) + " ";
    };
}
