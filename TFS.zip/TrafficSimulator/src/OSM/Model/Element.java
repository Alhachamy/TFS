package OSM.Model;

import java.util.HashMap;
import java.util.Map;

//*******************************************************
//‘*** Class Name: Element
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose of the class: An element is a generic OSM object.
//‘*** this classes takes data from the osm file and stores it
//‘******************************************************s
public abstract class Element {
	// The object ID, unique per object type
	protected long id;
	// The last editor name
	protected String user;
	// The last editor ID
	protected long uid;
	// The last edition time
	protected String timestamp;
	// Is this object visible or deleted?
	protected boolean visible;
	// The version of the object (default: 1)
	protected int version;
	// The last changeset ID
	protected long changeset;
	// The objects tags, which describe it
	protected Map<String,String> tags;

        // CONSTRUCTOR
        
	// Default constructor, initializes ID, version, visibility and tags. 
	// @param id The element ID
	public Element(long id) {
		this.id = id;
		version = 1;
		visible = true;
		tags = new HashMap<String,String>();
	}

        // Getters and Setters

	public abstract String getId();


	public String getUser() {
		return user;
	}


	public long getUid() {
		return uid;
	}


	public String getTimestamp() {
		return timestamp;
	}


	public boolean isVisible() {
		return visible;
	}


	public int getVersion() {
		return version;
	}


	public long getChangeset() {
		return changeset;
	}


	public Map<String, String> getTags() {
		return tags;
	}
	
	@Override
	public String toString() {
		return "Element "+getId()+" ("+getTags()+")";
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setUid(long uid) {
		this.uid = uid;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}


	public void setVisible(boolean visible) {
		this.visible = visible;
	}


	public void setVersion(int version) {
		this.version = version;
	}

	public void setChangeset(long changeset) {
		this.changeset = changeset;
	}


	public void addTag(String key, String value) {
		tags.put(key, value);
	}
	
	public void deleteTag(String key) {
		tags.remove(key);
	}
}
