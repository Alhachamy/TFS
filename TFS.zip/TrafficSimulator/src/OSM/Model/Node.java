package OSM.Model;

//*******************************************************
//‘*** Class Name: Node
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose of the class: A node is an OSM element with coordinates.
//‘***
//‘******************************************************
public class Node extends Element {
        // Members
	// Lats
	private double lat;
        // Lons
	private double lon;
	
        // CONSTRUCTOR
	// id The object ID
	// lat The latitude
	// lon The longitude
	public Node(long id, double lat, double lon) {
		super(id);
		this.lat = lat;
		this.lon = lon;
	}

        // Getters and Setters
	@Override
	public String getId() {
		return "N"+id;
	}

	public double getLat() {
		return lat;
	}

	public double getLon() {
		return lon;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public void setLon(double lon) {
		this.lon = lon;
	}
}
