
package OSM.Model;

import java.util.ArrayList;
import java.util.List;

//*******************************************************
//‘*** Class Name: Relation
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose of the class: A relation is a meta OSM object. It allows to combine other elements.
//‘***
//‘******************************************************

public class Relation extends Element {
        // Members
	// The relation members
	private List<Member> members;

        // CONSTRUCTOR
	public Relation(long id) {
		super(id);
		members = new ArrayList<Member>();
	}

        // Getters and Setters
	@Override
	public String getId() {
		return "R"+id;
	}
	
//‘******************************************************
//‘***  Method Name: getMemberRole
//‘***  Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: The role of this element, or null if no role
//‘*** Method Inputs:
//‘*** Parameters: Element e
//‘*** Return value: String
//‘******************************************************


	public String getMemberRole(Element e) {
		String result = null;
		
		boolean found = false;
		int index = 0;
		while(!found && index < members.size()) {
			if(members.get(index).elem == e) {
				found = true;
				result = members.get(index).role;
			}
			index++;
		}
		
		if(!found) {
			throw new RuntimeException("Element "+e.getId()+" not found");
		}
		
		return result;
	}
	

//‘******************************************************
//‘***  Method Name: getMembers
//‘***  Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: return The list of member elements
//‘*** Method Inputs:
//‘*** Parameters: none
//‘*** Return value: List
//‘******************************************************


	public List<Element> getMembers() {
		List<Element> elems = new ArrayList<Element>(members.size());
		for(Member m : members) {
			elems.add(m.elem);
		}
		return elems;
	}

//‘******************************************************
//‘***  Method Name: addMember
//‘***  Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: Adds a new member
//‘*** Method Inputs: 
//‘*** Parameters: role The role of the member, e The element
//‘*** Return value:
//‘******************************************************

        
	public void addMember(String role, Element e) {
		if(e == null) {
			throw new NullPointerException("Element can't be null");
		}
		
		members.add(new Member(role, e));
	}
	
	
	// Removes a member
	public void removeMember(Element e) {
		boolean found = false;
		int index = 0;
		while(!found && index < members.size()) {
			if(members.get(index).elem == e) {
				found = true;
				members.remove(index);
			}
			index++;
		}
	}
	
        //INNER CLASS Member
	private class Member {
                // Members
		// The member role
		private String role;
		// The member object
		private Element elem;
		
                // CONSTRUCTOR
		// Default constructor
		// role The member role
		// elem The member object
		private Member(String role, Element elem) {
			this.role = role;
			this.elem = elem;
		}
	}
}
