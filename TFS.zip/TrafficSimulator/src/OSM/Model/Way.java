
package OSM.Model;

import java.util.ArrayList;
import java.util.List;

//*******************************************************
//‘*** Class Name: Way
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose of the class: A way is an OSM element, which combines several Nodes to create a path.
//‘***
//‘******************************************************

public class Way extends Element {
        // ATTRIBUTES
	// The list of nodes of the way
	private List<Node> nodes;
	
        // CONSTRUCTER
	// id The object ID
	//  nodes Its nodes
	public Way(long id, List<Node> nodes) {
		super(id);
		
		//Conditions on nodes
		if(nodes == null) {
			throw new NullPointerException("Nodes list can't be null");
		}
		if(nodes.size() < 2) {
			throw new RuntimeException("A way should have at least two nodes");
		}
		
		this.nodes = nodes;
	}
	
	 // Constructor without nodes, not safe to use !
	 // Don't forget to add at least two nodes
	 // id The object ID
	public Way(long id) {
		super(id);
		this.nodes = new ArrayList<Node>();
	}

        
        // Getters and Setters
	@Override
	public String getId() {
		return "W"+id;
	}

	public List<Node> getNodes() {
		return nodes;
	}
        

	// n The node to add at the end of the way
	public void addNode(Node n) {
		nodes.add(n);
	}
	
	// index The index of the node to remove
	public void removeNode(int index) {
		if(nodes.size() == 2) {
			throw new RuntimeException("Can't remove node, only two remaining");
		}
		nodes.remove(index);
	}
}
