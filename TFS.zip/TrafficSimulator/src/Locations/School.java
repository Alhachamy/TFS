
package Locations;

import OsmParser.PNode;
import java.time.LocalTime;


public class School extends PNode{
    
    private String name;

    public School(PNode p) {
        super(p.getID()); 
        this.latitude = p.getLatitude();
        this.longitude = p.getLongitude();
    }
    
    
    public boolean IsActive(String currentTime){
        LocalTime theCurrentTime = LocalTime.parse(currentTime);
        
        return 
        (
            (theCurrentTime.isAfter(LocalTime.parse("07:00:00")) && theCurrentTime.isBefore(LocalTime.parse("09:00:00"))) 
                
                ||
                
            (theCurrentTime.isAfter(LocalTime.parse("14:30:00")) && theCurrentTime.isBefore(LocalTime.parse("16:30:00")))
                
        );

    }
    
    public void SetName(String name){
        this.name = name;
    }
    
    public String GetName(){
        return name;
    }
}
