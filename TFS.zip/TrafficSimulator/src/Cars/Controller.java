package Cars;
import Storage.DB;

//‘******************************************************
//‘*** Class Name: Controller
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: calculates distance between vehicles and 
//‘*** helps with overall AI
//‘******************************************************

public class Controller {
    // INIT DB OBJECT
    private DB db;
    // CONSTRUCTOR
    public Controller(DB database){
        // INIT DATABASE
        this.db = database;
    } 
    
//‘******************************************************
//‘*** Method Name: find
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: this method will look for a car and move it on a path
//‘*** Method Inputs: none
//‘*** parameters: double, double
//‘*** Return value: int
//‘******************************************************

    public int find(double lon, double lat)
    {
        // INIT FLAG
        boolean isFound = false;
        // INIT COUNTER
        int k = 0;
        // LOOP THROUGH LIST OF CARS
        for(int i=0; i < db.getVehicleListSize();i++){
            // CALL DISTANCE FUNCTION TO SET DISTANCE
            if(distance(lon,lat,db.getVehicle(i).getCorX(),db.getVehicle(i).getCorY())){
                // IF NOT FOUND
                if(!isFound){
                    // INCREMENT K
                    k = i;
                    // MOVE CAR
                    db.getVehicle(i).setTrackable(true);
                    // SET FOUND TRUE
                    isFound = true;
                }// OTHERWISE
                else{
                    // STOP CAR
                    db.getVehicle(i).setTrackable(false);
                }
            } // OTHERWISE
            else{
                // STOP CAR
                db.getVehicle(i).setTrackable(false);
            }
        } // IF FOUND RETURN COUNT
        if(isFound){
            return k;
        } // OTHERWISE RETURN INVALID
        else{
            return -1;
        }
    }

//‘******************************************************
//‘*** Method Name: distance
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: calculates the distance between two cars so they dont touch
//‘*** Method Inputs: x and y coordinates
//‘*** parameters: double, double, double, double
//‘*** Return value: boolean
//‘******************************************************

    private boolean distance(double x1, double y1, double x2, double y2){
        // returns this below formula
        // basic algebraic formula to calculate distance between two points
        return Math.sqrt(Math.pow(y2-y1,2) + Math.pow(x2-x1,2)) < 1.5*Math.pow(10,-4);
    } 
}
