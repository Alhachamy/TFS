
package Cars;

import OsmParser.PNode;
import OsmParser.Street;
import Storage.DB;
import java.util.Random;

//‘******************************************************
//‘*** Class Name: Logic
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this is the class that will handle car 
//‘*** instructions
//‘******************************************************

public class Logic {
    // INIT OBJECTS
    private DB DB;
    private Path route;
    private Street curStreet;
    private PNode curPoint;   
    private String position; 
    private Random rand = new Random();
    // INIT INTEGERS
    private int streetIndex;
    private int linkIndex; 
    private int wait = 0;
    private int randNum;
    // INIT BOOLEANS
    private boolean isMoveable = true; 
    private boolean inAccident = false;
    // INIT DOUBLES
    private double rate = 1;
    private double speed;  
    public double x;
    public double y;
    // CONSTRUCTOR
    public Logic(DB db){
        // INIT DATABASE
        this.DB = db;
        // INIT PATH OBJECT
        this.route = new Path();
        // INIT LOCATION
        this.setUpLocation();
    }
    
//‘******************************************************
//‘*** Method Name: setUpLocation
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: will randomly setup vehicle locaions on map
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void setUpLocation(){
        // SET INDEX TO A RANDOM POINT
        streetIndex = rand.nextInt(DB.getRoadListSize());
        // SET STREET TO THAT POINT
        curStreet = DB.getRoad(streetIndex);
        // SET NODE TO THAT STREET
        linkIndex = rand.nextInt(curStreet.getRef().size());
        // TYPE CAST ID TO THE STREET REFERENCE
        String ID = (String) curStreet.getRef().get(linkIndex);
        // INIT CURRENT POINT FROM DATABASE
        curPoint = DB.getPoint(ID);
        // INIT SPEED
        this.speed = curStreet.getSpeed();
        // INIT X BY CALLING LONGITUDE METHOD
        x = curPoint.getLongitude();
        // INIT Y BY CALLING LATITUDE METHOD
        y = curPoint.getLatitude();
        // INIT RANDOM NUMBER
        randNum = rand.nextInt(100);
        // IF RAND IS 55, DO A FORWARD LOOP
        if(randNum > 55)
        {
            position = "FL";
        }// ELSE DO A REVERSE LOOP
        else
        {
            position = "RL";
        }
    }
    
//‘******************************************************
//‘*** Method Name: setInAccident
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: this method sets an accident
//‘*** Method Inputs: boolean
//‘*** parameters: boolean
//‘*** Return value: void
//‘******************************************************

    public void setInAccident(boolean inAccident){
        // INIT BOOLEAN
        this.inAccident = inAccident;
        // IF ACCIDENT IS TRUE
        if(inAccident == true){
            // ADD IT TO DB
            DB.addAccident();
        } // ELSE
        else{
            // REMOVE AN ACCIDENT
            DB.subAccident();
        }
    }
    
//‘******************************************************
//‘*** Method Name: basicMove
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: this method just inits forward or reverse loop
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void basicMove(){    
        // CHECK IF FORWARD LOOP
        if(position.equals("FL")){
            // CALL METHOD
            forwardLoop(); 
        }// OTHERWISE 
        else if(position.equals("RL")){
            // REVERSE
            reverseLoop();
        }
    }

//‘******************************************************
//‘*** Method Name: forwardLoop
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: handles the logic for a forward and reverse loop
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void forwardLoop(){
        // CREATE A STREET ID
        String ID;
        // IF CAR ISNT ON ROUTE
        if(!route.onRoute()){   
            // ITERATE THROUGH STREETS
            if(linkIndex < this.curStreet.getRef().size()-1){
                // SET ID TO CURRENT STREET REF
                ID = (String) curStreet.getRef().get(linkIndex);
                // INIT A POINT AND GRAB IT FROM THE DB
                PNode p1 = DB.getPoint(ID);
                // FIND POINT THROUGH POLYMORPHYISM
                if((curPoint instanceof StopSign && this.curStreet.getType().equals("residential"))){
                    // STOP VEHICLE
                    isMoveable = false;
                    // WAIT FIVE SECONDS
                    wait = 5;
                }                
                // INCREMENT NODE INDEX
                linkIndex++;
                // SET THE ID TO THE NEXT LINK
                ID = (String) curStreet.getRef().get(linkIndex);
                // SET POINT TO THE NEXT POINT
                curPoint = DB.getPoint(ID);
                // CREATE A NEW ROUTE AND PASS IT OUR NEW POINTS
                route.newRoute(p1, curPoint);
                // CONVERT X AND Y COORDINATES           
                this.x = route.getLongitude();
                this.y = route.getLatitude();
                // UPDATE ROUTES
                route.update(rate);
            }
        } // IF CAR IS ON ROUTE
        else if (route.onRoute())
        {
            // SET LON
            this.x = route.getLongitude();
            // SET LAT
            this.y = route.getLatitude();
            // UPDATE TICK RATE
            route.update(rate);    
            // IF NOT ON ROUTE
            if(!route.onRoute()){
                // CALL MOVE METHOD AND UPDATE TICK RATE
                move(rate);
            }
        }
    }
    
//‘******************************************************
//‘*** Method Name: reverseLoop
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method:
//‘*** Method Inputs:
//‘*** parameters:
//‘*** Return value:
//‘******************************************************


    private void reverseLoop(){   
        // INIT ID
        String ID;
        // IF NOT ON ROUTE
        if(!route.onRoute()){        
            // IF NODE INDEX IS GREATER THAN 0
            if(linkIndex > 0)
            {
                // GET NODE REFERENCE
                ID = (String) curStreet.getRef().get(linkIndex);
                // GET NODE POINT FROM DATABASE
                PNode p1 = DB.getPoint(ID);
                // IF ROAD IS RESIDENTIAL
                if((curPoint instanceof StopSign && this.curStreet.getType().equals("residential"))){
                    // DON'T MOVE CAR
                    isMoveable = false;
                    // WAIT A FEW SECONDS
                    wait = 5;
                }                
                // DECREMENT INDEX
                linkIndex--;
                // GET ID REFERENCE
                ID = (String) curStreet.getRef().get(linkIndex);
                // GET CURRENT POINT FROM DB
                curPoint = DB.getPoint(ID);
                // ESTABLISH NEW ROUTE
                route.newRoute(p1, curPoint);
                // GET LONG         
                this.x = route.getLongitude();
                // GET LAT
                this.y = route.getLatitude();
                route.update(rate);
            }           
        }// ELSE IF ON ROUTE
        else if (route.onRoute()){
            // GET LONG
            this.x = route.getLongitude();
            // GET LAT
            this.y = route.getLatitude();
            // UPDATE TICK RATE
            route.update(rate);
            // IF NOT ON ROUTE
            if(!route.onRoute()){
                // UPDATE TICKRATE
                move(rate);
            }  
        }     
    }
    
//‘******************************************************
//‘*** Method Name: move
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: moves car up or down depends on loop type
//‘*** Method Inputs: none
//‘*** parameters: double
//‘*** Return value: void
//‘******************************************************

    public void move(double rate){
        // INIT RATE
        this.rate = rate;
        // CHECK IF ONE WAY
        if(curStreet.isOneWay()){
            position = "FL";
        }
        // CHECK IF MOVABLE
        if(isMoveable){
            // IF NOT ON ROUTE
            if(!route.onRoute()){   
                // CHECK IF REFERENCE IS OUT OF BOUND
                if(linkIndex == 0 || linkIndex == curStreet.getRef().size() - 1){ 
                    // CHECK IF POINT HAS PARENTS
                    if(curPoint.hasParents()){
                        // MOVE TO VALID ROUTE
                        relocate();
                        // MOVE CAR
                        basicMove();
                    }// OTHERWISE
                    else{
                        // IT'S A CORNER
                        cornerRoad(); 
                    }   
                }// OTHERWISE    
                else{
                    // MOVE TO VALID ROAD
                    possibleRelocate();
                    // MOVE CAR
                    basicMove();
                }
            }// OTHERWISE
            else{
                // MOVE CAR
                basicMove();
            }
        }// OTHERWISE
        else{
            // CHECK IF IS IN ACCIDENT
            if(!inAccident){
                // DECREMENT WAIT
                wait--;
                // MAKE CAR MOVABLE
                if(wait ==0){
                    isMoveable = true;
                }
            }
        }
  
    }
//‘******************************************************
//‘*** Method Name: relocate
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: moves car to valid road
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: none
//‘******************************************************

    private void relocate()
    {
        // INIT STREET
        Street tempRoad;
        // DO WHILE
        do{  
            // INIT RAND NUM TO A RANDOM POINT
            randNum = rand.nextInt(curPoint.getParentList().size());
            // SET THAT RANDOM POINT ON A STREET
            tempRoad = (Street) curPoint.getParentList().get(randNum);
            //WHILE WE ARE ON THE CURRENT ROAD
        }while(curStreet.getID().equals(tempRoad.getID()));
        // INIT STREET
        curStreet = tempRoad; 
        // GET SPEED
        this.speed = curStreet.getSpeed();
        // ITERATE THROUGH THE STREET
        for(int i=0; i < curStreet.getRef().size(); i++){
            // IF ID MATCHES
            if(curPoint.getID().equals(curStreet.getRef().get(i)))
            {
                // MAKE THIS THE CURRENT NODE
                this.linkIndex = i;
                // IF NODE IS ZER0 THEN FORWARD LOOP
                if(linkIndex == 0){
                    position = "FL";
                } // OTHERWISE REVERSE LOOP
                else if(linkIndex == curStreet.getRef().size() - 1 ){
                    position = "RL";
                } // OTHERWISE
                else{
                    // SET A NEW RANDOM INT
                    randNum = rand.nextInt(100);
                    // CHECK RANGE
                    if(randNum > 70){    
                        // FORWARD LOOP
                        position = "FL";
                    } // OTHERWISE REVERSE LOOP
                    else{
                        // REVERSER LOOP
                        position = "RL";
                    }
                } // OTHERWISE BREAK
                break;              
            }
        }
    }

//‘******************************************************
//‘*** Method Name: possibleRelocate
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: relocates car to appropriate route
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: none
//‘******************************************************

    private void possibleRelocate(){
        // INIT RANDOM NUMBER
        randNum = rand.nextInt(100);
        // CHECK IF CURRENT POINT HAS PARENTS
        if(curPoint.hasParents() && randNum > 70){
            // SET RANDOM NUM THE SIZE OF THE PARENTS TO THE CURRENT POINT
            randNum = rand.nextInt(curPoint.getParentList().size());
            // TYPE CAST TEMP ROAD
            Street tempRoad = (Street) curPoint.getParentList().get(randNum);
            // CHECK IF REFERENCES MATCH UP
            if(!(curStreet.getID().equals(tempRoad.getID()))){
                
                // SET CURRENT POINT
                curStreet = tempRoad;
                // SET SPEED
                this.speed = curStreet.getSpeed();
                // ITERATE THROUGH THE STREET REFERENCES
                for(int i=0; i < curStreet.getRef().size(); i++){
                    // IF THEY MATCH
                    if(curPoint.getID().equals(curStreet.getRef().get(i)))
                    {
                        // SET NODE INDEX TO CURRENT POINT
                        this.linkIndex = i;
                        // IF ITS ZERO
                        if(linkIndex == 0){
                            // FORWARD LOOP
                            position = "FL";
                        }// CHECK IF NODE IS NULL OR NOT
                        else if(linkIndex == curStreet.getRef().size() - 1 ){
                            // REVERSE LOOP
                            position = "RL";
                        }
                        else{
                            // INIT RAND
                            randNum = rand.nextInt(100);
                            // CHECK VALUE
                            if(randNum > 70){  
                                // FORWARD LOOP
                                position = "FL";
                            } // OTHERWISE
                            else{
                                // REVERSE LOOP
                                position = "RL";
                            }
                        }
                        // FORWARD LOOP ONE WAY STREETS
                        if(curStreet.isOneWay()){
                            position = "FL";
                        }
                        // DEFAULT BREAK
                        break;              
                    }
                }
            }
        }
    }
    
    // METHOD THAT CALLS SETUP LOCATION
    private void cornerRoad(){    
        setUpLocation();
    }
    
    // GETTERS
    // &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // RETURN ACCIDENT STATUS
    public boolean getInAccident(){ 
        return this.inAccident;
    }
    // RETURN POINT
    public PNode getPoint(){
        return curPoint;
    }
    // RETURN SPEED
    public double getSpeed(){
        return speed;
    }
    // RETURN STREET
    public Street getRoad(){
        return curStreet;
    }
    // RETURN DIRECTION
    public String getDirection(){
        return position;
    }
    
    // SETTERS
    // &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // SET CAR MOVE STATUS
    public void setIsMovable(boolean isMove){
        this.isMoveable = isMove;
    }
    // SET POINT
    public void setPoint(PNode p){
        this.curPoint = p;
    }
}
