package Cars;

import OsmParser.PNode;
//‘******************************************************
//‘*** Class Name: Path
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: will do the math for the car 
//‘*** paths
//‘******************************************************

public class Path {
    // INIT CONSTATNS
    private final double stdInc = 5.0 * Math.pow(10,-9);
    // INIT DOUBLES
    // INCREMENTER
    private double inc;
    // X1
    private double x1;
    // Y1
    private double y1;
    // NEW X
    private double newX;
    // NEW Y
    private double newY;
    // SLOPE
    private double dx;
    // LAST
    private double prev;
    // DIRECTION
    private String direction;
    // FLAGS
    private boolean isMoving;
    private boolean isUsable;
    // POINT OBJECT
    private PNode finalP;
    
    // CONSTRUCTOR
    public Path()
    {
        // INIT FLAG
        isMoving = false;
        // CLEAR DIRECTION
        direction = "";
        // INIT FLAG
        isUsable = true;
        // SET PREVIOUS
        prev = 1.0;
    }
    
//‘******************************************************
//‘*** Method Name: inc
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method moves car from one point to another
//‘*** along the path
//‘*** parameters: double double string
//‘*** Return value: double 
//‘******************************************************

    private double inc(double dY, double dX,String variable){   
        // INIT D, WHICH IS SCALER
        double d = Math.sqrt((Math.pow(dY,2) + Math.pow(dX,2)));
        // IF PARAM IS X
        if(variable.equals("x")){
            // RETURN SLOPE / SCALER
            return Math.abs(dX) / (d / stdInc);
        }   // OTHERWISE
        else{   
            // RETURN CHANGE IN Y OVER R SCALE
            return Math.abs(dY) / (d / stdInc);
        }
    }

//‘******************************************************
//‘*** Class Name: newRoute
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this method creates a new route for the 
//‘*** car to take
//‘******************************************************

    public void newRoute(PNode FROM_p1, PNode TO_p2){
        // INIT FLAGS
        isUsable = true;
        isMoving = true;
        // INIT PREV
        prev = 1.0;
        
        // INIT CHANGE IN X
        double deltaX = TO_p2.getLongitude() - FROM_p1.getLongitude();
        // INIT CHANGE IN Y
        double deltaY = TO_p2.getLatitude() - FROM_p1.getLatitude();
        // FIND X
        x1 = FROM_p1.getLongitude();
        // FIND Y
        y1 = FROM_p1.getLatitude();
        // FIND NEW X
        newX = FROM_p1.getLongitude();
        // FIND NEW Y
        newY = FROM_p1.getLatitude();
        // INIT FINAL POINT
        finalP = TO_p2;
        
        // CHECK IF CHANGE IN X IS NOT 0
        if(deltaX != 0){
            // SET SLOPE
            this.dx = deltaY/deltaX;
            // SET INC
            inc = inc(deltaY,deltaX, "x");
            // GET LONG
            newX = FROM_p1.getLongitude();
            // GET LAT
            newY = FROM_p1.getLatitude();
            // COMPARE THE LONGITUDE OF THE TWO POINTS
            if(FROM_p1.getLongitude() < TO_p2.getLongitude()){
                // SWITCH DIRECTION
                direction = "+";         
            } // OTHERWISE REVERSE COMPARE
            else if(FROM_p1.getLongitude() > TO_p2.getLongitude()){
                // SWITCH DIRECTION
                direction = "-";
            } 
        } // CHECK IF CHANGE IN X IS 0
        else if(deltaX == 0){
            // SET FALSE FLAG
            isUsable = false;
            // SET INC TO Y
            inc = inc(deltaY, deltaX, "y");
            // COMPARE LATITUDE        
            if(FROM_p1.getLatitude() < TO_p2.getLatitude()){
                // SET DIRECTION
                direction = "+";         
            } // REVERSE COMPARE
            else if(FROM_p1.getLatitude() > TO_p2.getLatitude()){
                // SET DIRECTION
                direction = "-";
            }
        }
    }
    
//‘******************************************************
//‘*** Method Name: isTooFar
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: returns if car has strayed too far
//‘*** Method Inputs: none 
//‘*** parameters: none 
//‘*** Return value: boolean
//‘******************************************************

    private boolean isTooFar(){
        // INIT CHANGE IN Y
        double dY = finalP.getLatitude() - newY;
        // INIT CHANGE IN X
        double dX = finalP.getLongitude() - newX;
        // INIT D WHICH IS THE SCALE
        double d = Math.sqrt((Math.pow(dY,2) + Math.pow(dX,2)));
        // COMPARE D TO PREVIOUS SCALE
        if( prev > d){
            // SET PREVIOUS TO CURRENT SCALE
            prev = d;
            // RETURN FALSE
            return false;
        } // OTHERWISE
        else{   
            // RETURN TRUE
            return true;
        }    
    }
    
//‘******************************************************
//‘*** Method Name: update
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method updates paths
//‘*** Method Inputs: none
//‘*** parameters: double
//‘*** Return value: void
//‘******************************************************

    public void update(double rate){
        // INIT OLD X
        double oldx = newX;
        // INIT OLD Y
        double oldy = newY;
        // SWITCH STATEMENT
        if(isUsable){
            // CHECK DIRECTION
            switch (direction) {
                // IF +
                case "+":
                    // UPDATE ACCORDINGLY
                    newX += inc * rate;
                    newY = dx * (newX  - x1) + y1;
                    break;
                    // IF -
                case "-":
                    // UPDATE ACCORDINGLY
                    newX -= inc * rate;
                    newY = dx * ((newX) - x1) + y1;
                    break;
                    // DEFAULT CASE JUST BREAKS OFF
                default:
                    break;
            }
        }// IF NOT USEABLE  
        else{
            // CHECK DIRECTION
            switch (direction) {
                // IF +
                case "+":
                    // UPDATE
                    newY += inc * rate;
                    break;
                    // IF -
                case "-":
                    // UPDATE
                    newY -= inc * rate;
                    break;
                    // DEFAULT BREAK
                default:
                    break;
            }
        }
        // CALL TOO FAR TO GET BOOLEAN FLAG    
        if(isTooFar()){
            // SET X
            newX = oldx;
            // SET Y
            newY = oldy;
            // STOP CAR
            isMoving = false;
        }  
    }
    
    // RETURNS ONROUTE BOOLEAN
    public boolean onRoute(){
        // RETURN BOOLEAN
        return isMoving;
    }
    // GETTER
    public double getLongitude(){
        // RETURN LON
        return newX;
    }
    // GETTER
    public double getLatitude(){
        // RETURN LAT
        return newY;
    }
}
