package Cars;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Area;
import java.awt.geom.Rectangle2D;

//‘******************************************************
//‘*** Class Name: Sedan
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this class creates a bus vehicle, inherits
//‘*** from Car class
//‘******************************************************

public class Sedan extends Car{
    
    // CONSTRUCTOR
    public Sedan(Logic logic) 
    {
        // CALL SUPER
        super(logic);
        // SET LOGIC
        this.logic = logic;
        // SET COLOR
        color = Color.ORANGE;
        // SET SPEED
        speed = 45;
    }
    
//‘******************************************************
//‘*** Method Name: Move
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: Moves car
//‘*** Method Inputs: none
//‘*** parameters: double rate
//‘*** Return value: none
//‘******************************************************

    @Override
    public void move(double rate){
        // CHANGE TICKRATE
        logic.move(rate*speed*200);
        // SET SPEED
        speed = logic.getSpeed();
    }
    @Override
//‘******************************************************
//‘*** Method Name: draw
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: draws a bus vehicle
//‘*** Method Inputs: none
//‘*** parameters: graphics2d, double, double, double, double, double
//‘*** Return value: void
//‘******************************************************

    public void draw(Graphics2D g,double x1,double y1, double d1,double d2,double scale){
        // CHECK IF VEHICLE
        if(locate){
            // SET COLOR
             g.setColor(Color.YELLOW);
        }
        // CHECK ACCIDENT
        if(logic.getInAccident()){
            // SET ACCIDENT COLOR
            g.setColor(Color.YELLOW);
            // CHECK COUNT
            if(count == 0){
                // SET COLOR
                g.setColor(Color.RED);
                // UPDATE ACOUNT
                count++;
            }else{
                // DECREASE COUNT
                count--;
            }
        }
        // CREATE SHAPE OF VEHICLE
        Area a1 = new Area(new Rectangle2D.Double(x1 - (d1), y1-(d1), 3*d1, 3*d1)); 
        // FILL THE CAR WITH THAT AREA
        g.fill(a1);
    }
}


