package Cars;
import OsmParser.PNode;
import OsmParser.Street;
import java.awt.Color;
import java.awt.Graphics2D;

//‘******************************************************
//‘*** Class Name: CAR
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: This is the car class, it will create 
//‘*** a car and give it properties
//‘******************************************************

public class Car {
    // INIT COLOR
    protected Color color;
    // INIT AI
    protected Logic logic;
    // INIT SPEED
    protected double speed;
    // INIT ID
    protected int carID;
    // INIT TRACKING
    protected boolean locate;
    // INIT CAR COUNTER
    private static int carCount;
    // INIT ACCIDENT COUNT
    protected int count;
    
    // CONSTRUCTOR
    public Car(Logic logic)
    {       
        // SET ID
        carID = carCount;
        // SET AI
        this.logic = logic;
        // SET LOCATOR
        locate = false;
        // SET COUNT
        carCount++;
    }
    // GETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // RETURN ID
    public int getID(){
        return carID;
    }
    // RETURN POINT
    public PNode getPoint(){
        return logic.getPoint();
    }
    // RETURN X
    public double getCorX(){
        return logic.x;
    }
    // RETURN Y
    public double getCorY(){
        return logic.y;
    }
    // RETURN ROAD
    public Street getRoad(){
        return logic.getRoad();
    }
    // RETURN SPEED
    public double getSpeed(){
        return logic.getSpeed();
    }
    // RETURN COLOR
    public Color getColor(){
        return color;
    }
    // RETURN ACCIDENT STATUS
    public boolean getInAccident(){
        return logic.getInAccident();
    }
    
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // SET POINT
    public void setPoint(PNode p){
        logic.setPoint(p);
    }
    // SET COLOR
    public void setColor(Color color){
        this.color = color;
    }
    // SET LOCATION
    public void setTrackable(boolean track){
        this.locate = track;
    }
    // SET ACCIDENT
    public void setInAccident(boolean inAccident)
    {   
        // SET ACCIDENT AND PASS IT BOOLEAN
        logic.setInAccident(inAccident);
        // MAKE CAR STOP
        if(inAccident)
        {
            logic.setIsMovable(false);
        }
        // MAKE IT MOVE IF FALSE
        else
        {
            logic.setIsMovable(true);
        }
    }
    
//‘******************************************************
//‘*** Method Name: Move
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: moves car, updates tick rate
//‘*** Method Inputs: none
//‘*** parameters: double rate
//‘*** Return value: void
//‘******************************************************

    public void move(double rate){
        // UPDATE TICKRATE
        logic.move(rate*1000);
    }
    // DRAW METHOD THAT IS ALSO IN BUS AND SEDAN, OVERRIDEN HERE
    public void draw(Graphics2D g,double x1,double y1, double d1,double d2,double scale){
        // OVERRIDE METHOD
    }
}
