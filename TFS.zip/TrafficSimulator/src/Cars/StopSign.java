
package Cars;

import OsmParser.PNode;

public class StopSign extends PNode{
    
    public StopSign(PNode p) {
        super(p.getID()); 
        this.latitude = p.getLatitude();
        this.longitude = p.getLongitude();
        this.parentList = p.getParentList();
    }
    
}
