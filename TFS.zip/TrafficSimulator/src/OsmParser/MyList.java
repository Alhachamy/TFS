package OsmParser;

//‘******************************************************
//‘*** Class Name: MyList
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: linked list that will be used for a differnt class.
//‘*** will help setup points
//‘******************************************************

public class MyList {
    // INIT NODE OBJECT
    private PNode point;
    // NODE NEXT
    private MyList next;
    
    // GETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public PNode getNode(){
        return point;
    }
    
    public MyList getNextLink(){
        return next;
    }
    
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public void setPoint(PNode point){
        this.point = point;
    }
    
    public void setLinkList(MyList link) {
        this.next = link;
    }
}
