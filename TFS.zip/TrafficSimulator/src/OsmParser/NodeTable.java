package OsmParser;

//‘******************************************************
//‘*** Class Name: NodeTable
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: table of nodes that will help parse the osm file
//‘***
//‘******************************************************

public class NodeTable {
    // INIT TABLE OBJECT
    private final MyList[] Table;
    
    // CONSTRUCTOR
    public NodeTable(){
        // SET TABLE
        Table = new MyList[10000];     
    }
    
    // HASH METHOD
    private Long HashFunctionKey(String curPointID){
        // RETURN PARSED LONG
        return Long.parseLong(curPointID) % 10000;
    }
    
    
//‘******************************************************
//‘*** Method Name: adder
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: adds point to hash map
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    public synchronized void adder(PNode newPoint){ 
        
        try
        {
            // GRAB KEY 
            int indexKey = Integer.parseInt(HashFunctionKey(newPoint.nodeID).toString());

            // IF ARRAY IS EMPTY
            if(Table[indexKey] == null){
                // FILL IT
                // INIT LIST
                MyList newObj = new MyList(); 
                // SET POINT
                newObj.setPoint(newPoint); 
                // SET NULL
                newObj.setLinkList(null); 
                // TYPE CAST INDEX KEY
                Table[indexKey] = newObj;         
            }
            else{   
                // TEMP LIST WILL REFERNCE ARRAY
                MyList temp = Table[indexKey];
                // DO          
                do{
                    // COMPARE IDS
                    if(newPoint.getID().equals(temp.getNode().getID())){   
                        // SET TEMP AND BREAK
                        temp.setPoint(newPoint); 
                        break;
                    }
                    // IF LINK DOESN'T EXIT, MAKE NEXT
                    else if(temp.getNextLink() == null)
                    {
                        // INIT NEW OBJECT
                        MyList newObj = new MyList();
                        // SET POINT
                        newObj.setPoint(newPoint); 
                        // TYPE CAST TEMP AND BREK
                        temp.setLinkList(newObj);    
                        break;
                    } 
                    else{  
                        // GET THE NEXT LINK
                        temp = temp.getNextLink();
                    }   
                    // CONTINUE IF NOT NULL
                }while(temp != null);
            } 
        } // CATCH ERRORS
        catch(Exception e)
        {
            return;
        }
    }
    
//‘******************************************************
//‘*** Method Name: getPoint
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method that returns point
//‘*** Method Inputs: none
//‘*** parameters: string id
//‘*** Return value: PNode
//‘******************************************************


    public PNode getPoint(String PointID){
        // INIT OBJECT TO NULL
        PNode point = null;
        
        try
        {
            // GRAB KEY
            int indexKey = Integer.parseInt(HashFunctionKey(PointID).toString());
            // IF NOT EMPTY
            if(Table[indexKey] != null){
                // INIT TEMP LIST
                MyList temp = Table[indexKey]; 
                // DO
                do{
                    // IF CORRECT NODE, RETURN OBJECT
                    if(temp.getNode().getID().equals(PointID)) {
                        // GET THE POINT
                        point = temp.getNode();
                        // END LOOP
                        break;
                    } 
                    // IF THE NEXT LINK IS THE CORRECT OBJECT, GET IT
                    else if(temp.getNextLink().getNode().getID().equals(PointID)){
                        // GET THE OBJECT
                        point = temp.getNextLink().getNode();
                        // END LOOP
                        break;
                    }   // IF NOT NULL
                    else if(temp.getNextLink() != null){
                        // GO TO THE NEXT LINK
                        temp = temp.getNextLink();
                    }
                    else{
                        // DEFAULT BREAK
                        break;
                    }// END WHILE
                }while(!(temp.getNode().getID().equals(PointID)));

            } // CATCH ERROR
        }catch(Exception e){
            e.printStackTrace();
        }
        // RETURN OBJECT
        return point;
    }
}
