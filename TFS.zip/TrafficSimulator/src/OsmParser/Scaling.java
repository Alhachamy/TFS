package OsmParser;

//‘******************************************************
//‘*** Class Name: Scaling
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this class will setup the conversion from lat lon to x and y
//‘***
//‘******************************************************

public class Scaling {
    // SET ALL CONSTANTS
    private final double highA;
    private final double lowA;
    private final double highB;
    private final double lowB;
    private final double rangeA;
    private final double rangeB;
    
    // CONSTRUCTOR
    public Scaling(double deltaH, double deltaL, double highB,double lowB){
        // PASS LAT LON X AND Y AND SCALER
        this.highA = deltaH;
        this.lowA = deltaL;
        this.highB = highB;
        this.lowB = lowB;
        this.rangeA = this.highA - this.lowA;
        this.rangeB = this.highB - this.lowB;  
    }

//‘******************************************************
//‘*** Method Name: Scale
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: do the math equation to scale properly
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: double
//‘******************************************************

    public double Scale(double val){
        // Math algorith
        // this was found on google maps api
        double num =  val - this.lowA;
        double dcNum = num / this.rangeA;
        double dNormNum = this.rangeB * dcNum;
        double finalNum = this.lowB + dNormNum;
        // return final number
        return finalNum;
    }
    // this just sets the original values that were passed instead of the converted
    // ones
    public double unScale(double val)
    {
        double num = val - this.lowB;
        double dcNum = num / this.rangeB ;
        double number =dcNum * this.rangeA;
        double ogNum = number + this.lowA;
        
        return ogNum;

    }
}
