
package OsmParser;

import Cars.StopSign;
import Storage.DB;
import java.util.ArrayList;
//‘******************************************************
//‘*** Class Name: Signs
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: class sets up road signs
//‘***
//‘******************************************************

public class Signs {
    // DB OBJECT
    private final DB db;
    // CONSTRUCTOR
    public Signs (DB db){  
        // SET PASSED VALUE
        this.db = db;
    }

//‘******************************************************
//‘*** Method Name:
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method:
//‘*** Method Inputs:
//‘*** parameters:
//‘*** Return value:
//‘******************************************************

    public void CreateStopSigns(Street curRoad){
        // CHECK IF ROAD TYPE IS RESIDENTIAL
        if(curRoad.getType().equals("residential")){
            // CREATE SIGN
            StopSign ss;
            // INIT ARRAYLIST OF REFS    
            ArrayList curRef = (ArrayList)curRoad.getRef();
            // INIT NODE TO NULL    
            PNode p1 = null;
            // ITERATE THROUGH REFERENCES
            for(int i = 0; i < curRef.size(); i++){
                // SET POINT TO CURRENT INDEX
                p1 = db.getPoint((String)curRef.get(i));
                // IF POINT HAS PARENTS
                if(p1.hasParents()){      
                    // SET SIGN TO NEW STOP SIGN AT THAT SPECIFIC POINT
                    ss = new StopSign(p1);
                    // ADD TO DATABASE
                    db.addPoint(ss);   
                }   
            }  
        }
    }
    
}
