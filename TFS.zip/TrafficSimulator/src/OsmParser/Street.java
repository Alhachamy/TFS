
package OsmParser;

import java.util.ArrayList;
//‘******************************************************
//‘*** Class Name: Street
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this class has all properties of a street
//‘***
//‘******************************************************

public class Street {
    // ALL STRING PROPERTIES
    private String roadID;
    private String name;
    private String type;
    // ALL ARRAYLISTS
    private ArrayList ref;
    private ArrayList detailedRef;
    // ALL INTS
    private int lane;
    private int speed;
    // ALL FLAGS
    private boolean oneway;
    // CONSTRUCTOR
    public Street(){
        // INIT VALUES
        this.ref = new ArrayList();
        this.speed = 35;
        this.lane = 2;
        this.oneway = false;
    }
    // NOTHING REALLY SPECIAL BELOW, JUST GETTERS AND SETTERS
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public void setName(String name){
        this.name = name;
    }
        
    public void setRef(ArrayList ref){
        this.ref = ref;
    }
    
    public void setDetailedRef(ArrayList ref){
        this.detailedRef = ref;
    }
    
    public void setID(String ID){
        this.roadID = ID;
    }
        
    public void setSpeed(int speed){
        this.speed = speed;
    }
            
    public void setType(String type){
        this.type = type;
    }
     
    public void setLane(int lane){
        this.lane = lane;
    }
     
    public void setOneway(Boolean oneway){
        this.oneway = oneway;
    }
    
    // GETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public String getName(){
        return this.name;
    }

    public ArrayList getRef(){
        return this.ref;
    }
    
    
    public ArrayList getDetailedRef(){
        return this.detailedRef;
    }
   
    
    public String getID(){
        return this.roadID;
    }
    
    
    public int getSpeed(){
        return this.speed;
    }
    
    
    public String getType(){
        return this.type;
    }
    
    
    public int getLane(){
        return this.lane;
    }
   
    
    public boolean isOneWay(){
        return this.oneway;
    }
    
}
