package OsmParser;

import Locations.School;
import Storage.DB;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.*;

//‘******************************************************
//‘*** Class Name: ReadFile
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this is the class that parses the osm file
//‘***
//‘******************************************************

public class ReadFile {
    // INIT DOCUMENT
    private Document osmDoc;
    // INIT DATABASE
    private DB db;
    
    // CONSTRUCTOR
    public ReadFile(String dir){
        // PASS THE DIRECTORY FROM THE MAIN GUI TO THIS CLASS
        this.osmDoc = getDocument(dir);
        // INIT NEW DATABASE
        db = new DB();
    }

//‘******************************************************
//‘*** Method Name: getDocument
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: grabs document
//‘*** Method Inputs: none
//‘*** parameters: String docString
//‘*** Return value: none
//‘******************************************************
    private  Document getDocument(String docString){
        try{
            // CALL JAVA'S BUILD FACTOR
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // SET PROPERTIES 
            factory.setIgnoringComments(true);
            factory.setIgnoringElementContentWhitespace(true);
            factory.setValidating(false);
            // INIT DOC BUILDER
            DocumentBuilder builder = factory.newDocumentBuilder();
            // RETURN PARSED DOC
            return builder.parse(new InputSource(docString));          
        } // CATCH ERRORS
        catch(Exception e){
            e.printStackTrace();
        }
        // RETURN NULL
        return null;
    }
//‘******************************************************
//‘*** Method Name: getBounds
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: return highest and lowest lat and lon values
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************
    private void GetBounds(){
        // INIT A LIST FOR THE BOUNDS
        NodeList listOfBounds = osmDoc.getElementsByTagName("bounds");
        // INIT A NODE TO HOLD ONE BOUND
        Node bound =  listOfBounds.item(0);
        // GO TO THE TOP OF THE OSM FILE AND GRAB THE MINLAT, MINLON, MAXLAT, MAXLON VALUES
        db.setBounds(0, Double.parseDouble(bound.getAttributes().getNamedItem("minlat").getNodeValue()));
        db.setBounds(1,Double.parseDouble(bound.getAttributes().getNamedItem("minlon").getNodeValue()));
        db.setBounds(2,Double.parseDouble(bound.getAttributes().getNamedItem("maxlat").getNodeValue()));
        db.setBounds(3,Double.parseDouble(bound.getAttributes().getNamedItem("maxlon").getNodeValue()));     
    }

//‘******************************************************
//‘*** Method Name: GetRoads
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: grab roads from osm file
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private  void GetRoads(){
        // INIT FLAG
        boolean Accept;
        // INIT FLAG
        boolean oneway;
        // INIT ROAD
        Street Rd;
        // INIT ROAD NAME
        String roadName;
        // INIT ROAD ID
        String roadID;
        // INIT REF ID
        String refID;
        // INIT TYPE
        String type;
        // INIT SPEED
        int speed;
        // INIT EMPTY LIST
        ArrayList<String> ref = null;
        // INIT ATTRIBUTE KEY
        String attrK;
        // INIT ATTRIBUTE VALUE
        String attrV;
        
        // GET ONLY ELEMENTS THAT ARE OF TYPE WAY
        NodeList listOfWays = osmDoc.getElementsByTagName("way");
        // TRY
        try{
            // ITERATE THROUGH LIST OF WAYS
            for(int i=0; i < listOfWays.getLength(); i++){
                // SET FLAG
                Accept = false;
                // SET ALL STRINGS
                roadName = "";
                roadID = "";
                refID = "";
                // SET FLAG
                oneway = false;
                // SET ALL OTHER STRINGS       
                attrK = "";
                attrV = "";
                type = "";
                speed = 0;
                // ALL OF THE ABOVE ARE ELEMENT HEADERS IN THE XML FILE
                
                // INIT NODE TO CURRENT INDEX
                Node theNode = listOfWays.item(i);
                // STORE ID
                String NodeID = theNode.getAttributes().getNamedItem("id").getNodeValue();                
                // TYPE CAST ELEMNT OBJECTS
                Element curElement = (Element) theNode;
                // STORE TAG
                NodeList refList2 = curElement.getElementsByTagName("tag");
                // ITERATE THROUGH ALL REFERENCES
                for(int j = 0; j < refList2.getLength(); j++){
                    // INIT NEW ARRAY LIST
                    ref = new ArrayList();
                    // INIT SECOND REFERENCE LIST
                    Node refList2Element = refList2.item(j);
                    
                    // LEAVE OUT ADMIN ELEMENTS
                    if(!refList2Element.getAttributes().getNamedItem("k").getNodeValue().equals("admin_level")){
                        // STORE THE KEY
                        attrK = refList2Element.getAttributes().getNamedItem("k").getNodeValue();
                        // STORE THE VALUE
                        attrV = refList2Element.getAttributes().getNamedItem("v").getNodeValue();
                        // SWITCH STATEMENT
                        switch(attrK){
                            // CASE NAME
                            case("name"):  
                                // SET ID AND NAME AND VALUE
                                roadID = NodeID;
                                roadName = attrV;
                                break;
                                // ONE WAY
                            case("oneway"):
                                // IF ONE WAY
                                if(!(attrV.equals("no"))){
                                    // SET TRUE
                                    oneway = true; 
                                }
                                break;
                                // IF HIGHWAY
                            case("highway"):
                                // CHECK HIGH WAY TYPE
                                if(!(attrV.equals("service") || attrV.equals("footway") || 
                                        attrV.equals("track") || attrV.equals("pedestrian") || 
                                        attrV.equals("paved") || attrV.equals("path"))){
                                    // IF EMPTY
                                    if(roadName.isEmpty()){
                                        // SET NAME TO UNKOWN
                                        roadName = "UNKNOWN";
                                    }
                                    // SET VALUE
                                    type = attrV;
                            // CHECK TYPE AND SET SPEEDS ACCORDINGLY        
                            switch (type) {
                                case "primary":
                                case "motorway":
                                    speed = 75;
                                    break;
                                    
                                case "secondary":
                                case "trunk":
                                case "unclassified":
                                    speed = 50;
                                    break;
                                    
                                case "tertiary":
                                case "road":
                                    speed = 45;
                                    break;
                                    
                                case "residential":
                                    speed = 35;
                                    break;
                                    
                                default:
                                    speed = 30;
                                    break;
                            }
                                    // SET NODE ID
                                    roadID = NodeID;
                                    // ACCEPT STREET
                                    Accept = true;  
                                }                              
                                break;
                            // DEFAULT BREAK   
                            default:     
                                break;
                        }
                    } // ELSE BREAK
                    else{
                        break;
                    }
                }
                // INIT NODE LIST OF TYPE ND
                NodeList refList = curElement.getElementsByTagName("nd");
                
                // IF ROAD IS ACCEPTED, CONTINUE
                if(Accept)
                {
                    // ITERATE THROUGH LIST
                    for(int j = 0; j < refList.getLength(); j++){
                        // STORE CURRENT REFERENCE
                        Node refListElement = refList.item(j);
                        // STORE THE NUMBER AND STRING VALUE
                        refID = refListElement.getAttributes().getNamedItem("ref").getNodeValue();
                        // ADD REFERENCE TO ARRAYLIST
                        ref.add(refID);
                    }
                    
                    // INIT NEW STREET
                    Rd = new Street();
                    //SET ROAD ID
                    Rd.setID(roadID);
                    //SET ROAD NAME
                    Rd.setName(roadName);
                    //SET REF 
                    Rd.setRef(ref); 
                    //SET ROAD TYPE
                    Rd.setType(type);
                    // SET SPEED
                    Rd.setSpeed(speed);
                    // SET ONE WAY
                    Rd.setOneway(oneway);
                    // ADD ACCEPTED ROADS TO DATABASE
                    db.addRoad(Rd);  
                }   
            }
        } // CATCH ERRORS
        catch(Exception e){

            e.printStackTrace();
        }
    }
    
//‘******************************************************
//‘*** Method Name: GetPoints
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: returns list of points
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void GetPoints(){   
        // INIT NEW LIST
        NodeList listOfNodes = osmDoc.getElementsByTagName("node");
        // INIT CONSTANTS
        String name = "";
        // KEY
        String attrK;
        // VALUE
        String attrV;
        // SCHOOL OBJECT
        School school;
        // FLAG
        boolean isAcceptable = false;
        // LENGTH OF LIST
        int length = listOfNodes.getLength();
        // NODE COPY
        Node[] copy = new Node[length];
        // LOOP
        for(int i =0; i < length ; i++){
            // COPY LIST
            copy[i] = listOfNodes.item(i);
        }
        
        // NULL LINK 
        PNode curPoint = null;
        // ITERATE THROUGH COPY
        for(int i=0; i < copy.length; i++ ){
            // CLEAR NAME
            name="";
            // SET FLAG
            isAcceptable = false;
            // SET INDEX
            Node curNode = copy[i];
            // SET CURRENT POINT
            curPoint = new PNode(curNode.getAttributes().getNamedItem("id").getNodeValue());
            //SET LATITUDE
            curPoint.setLatitude(Double.parseDouble(curNode.getAttributes().getNamedItem("lat").getNodeValue()));
            //SET LONGITITUDE
            curPoint.setLongitude(Double.parseDouble(curNode.getAttributes().getNamedItem("lon").getNodeValue()));
            // TYPE CAST ELEMENT
            Element curElement = (Element) curNode;
            // GET TAG
            NodeList refList2 = curElement.getElementsByTagName("tag");

            // ITERATE THROUGH TAGS
            for(int j = 0; j < refList2.getLength(); j++){
                // CREATE A NODE REF
                Node refList2Element = refList2.item(j);
                          
                // STORE KEY TAG
                attrK = refList2Element.getAttributes().getNamedItem("k").getNodeValue();
                // STORE VALUE TAG
                attrV = refList2Element.getAttributes().getNamedItem("v").getNodeValue();
                // IF NOT IN THE LIST
                if(!refList2Element.getAttributes().getNamedItem("v").getNodeValue().equals("school")){
                    // SWITCH
                    switch(attrK){ 
                        // NAME
                        case("name"): 
                            // SET NAME
                            name = attrV;
                            break;
                            // BREAK
                        default:     
                            break;      
                    }
                }
                else{
                    // SET FLAG
                    isAcceptable = true;
                }
            }
            // COMPARE
            if(isAcceptable){
                // INIT SCHOOL
                school = new School(curPoint);
                // ADD SCHOOL
                db.addSchool(school);
                // ADD SCHOOL
                db.addPoint(school);
            }
            else{
                // ADD POINT TO DB
                db.addPoint(curPoint); 
            }
        }
    }
    
//‘******************************************************
//‘*** Method Name: AssignParents
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: AssignParents to list
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void AssignParents(){
        // INIT ARRAYLIST OF STRINGS
        ArrayList<String> refID;
        // INIT NODE
        PNode p;
        // ITERATE THROUGH ROADS
        for(int i = 0; i < db.getRoadListSize(); i++){
            // SET CURRENT INDEX AS THE REF
            refID = db.getRoad(i).getRef();
            // ITERATE THROUGH LIST OF REFS
            for(int j = 0 ; j < refID.size(); j++){
                // GET THE POINT FROM THE DATABASE
                p = db.getPoint(refID.get(j));
                // SET THE POINT AS A CHILD
                p.addParent(db.getRoad(i));            
            }
        }
    }
    
//‘******************************************************
//‘*** Method Name: CreateSigns
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: creates stop signs
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void CreateSigns(){
        // CREATE SIGN OBJECT
        Signs CS = new Signs(db);
    
        // ITERATE THROUGH LIST OF NODES
        for(int i = 0; i < db.getRoadListSize(); i++){
            // CREATE SIGN AT INDEX
            CS.CreateStopSigns(db.getRoad(i));          
        }
    }

//‘******************************************************
//‘*** Method Name: MainCalculation
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method that will call all other methods in this class
//‘*** Method Inputs:
//‘*** parameters:
//‘*** Return value:
//‘******************************************************

    public void MainCalculation() {
        // call all methods to read file properly
        GetBounds();
        GetRoads();
        GetPoints();            
        AssignParents();
        CreateSigns();    
    }
    // GETTER
    public DB getDatabase(){
         return this.db;
    } 
}
