package OsmParser;
//‘******************************************************
//‘*** Class Name: PNode
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: container class that helps parse file,
//‘*** a part of many other classes that take part in this task
//‘******************************************************

import java.util.ArrayList;

public class PNode {
    // INIT ID
    String nodeID;
    // LAT
    protected double longitude;
    // LON
    protected double latitude;
    // LIST OF PARENTS
    protected ArrayList<Street> parentList;
    // CONSTRUCTOR
    public PNode(String nodeID){
        // SET ID
        this.nodeID = nodeID;
        // SET PARENTS
        parentList = new ArrayList();
    }
    
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    } 
    
    // GETTERS
    // &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public double getLatitude() {
        return latitude;
    }
    
    public String getID(){
        return this.nodeID;
    }
    
    public double getLongitude() {
        return longitude;
    }
   
    public ArrayList<Street> getParentList() {
        return this.parentList;
    }
    
    public boolean hasParents(){
        return this.parentList.size() > 1;
    }
    
//‘******************************************************
//‘*** Method Name: addParent
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: adds parents to hash map
//‘*** Method Inputs: none
//‘*** parameters: Street id
//‘*** Return value: void
//‘******************************************************

    public void addParent(Street parentID) {
        // IF NOT NULL
        if(!this.parentList.isEmpty()){
            // IF NOT IN LIST
            if(!this.parentList.contains(parentID)){
                // ADD IT
                this.parentList.add(parentID);
            }
        } // OTHERWISE
        else{
            // ADD IT
            this.parentList.add(parentID);
        }   
    }
}
