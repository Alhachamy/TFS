package Graphics;

import OsmParser.PNode;
import OsmParser.Scaling;
import Storage.DB;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.util.ArrayList;

//‘******************************************************
//‘*** Class Name: JavaGraphs
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: THIS IS THE CLASS THAT DRAWS ROADS AND CARS
//‘***
//‘******************************************************

public class JavaGraphs {
    // INIT DATABASE
    private final DB database;
    // INIT X SCALE
    private Scaling chX;
    // INIT Y SCALE
    private Scaling chY;
    // INIT WIDTH
    private int W = 10000;
    // INIT HEIGHT
    private int H = 9000;
    // INIT SCALE
    private double scaler = 1;
    // MOVE X AND Y
    double moveX;
    double moveY;
    // CONSTRUCTOR
    public JavaGraphs(DB db){
        // PASS DATABASE
        this.database = db;
        // SCALE REGION
        scaleZone();
    }
    
    
//‘******************************************************
//‘*** Method Name: scaleZone
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: this method scales the window
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    private void scaleZone(){
        // MIN AND MAX LON, MIN MAX X COORDINATE, AND BOUNDS
        chX = new Scaling(database.getBounds(3), database.getBounds(1), this.W, 0); 
        // MIN AND MAX LAT, MIN MAX X COORDINATE, AND BOUNDS
        chY = new Scaling(database.getBounds(2), database.getBounds(0), this.H, 0);
    }

//‘******************************************************
//‘*** Method Name: DrawRoad
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: method that draws road
//‘*** Method Inputs: none
//‘*** parameters: graphics g
//‘*** Return value: void
//‘******************************************************

    public void DrawRoad(Graphics g){
        // INIT GRAPHICS OBJECT
        Graphics2D pen = (Graphics2D) g.create();
        // SET STROKE
        pen.setStroke(new BasicStroke(1));
        // ADD ANTIALIASING
        pen.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        pen.setColor(Color.DARK_GRAY);
        // INIT POINT
        PNode p ;
        // INIT X AND Y
        double x1;
        double y1 ;
        // INIT SECOND POINT
        PNode p2;
        // INIT X AND Y
        double x2 ;
        double y2;
        // INIT ARRAYLIST OF POINTS
        ArrayList<String> curRoadPoints;
        // ITERATE THROUGH ALL ROADS
        for(int i = 0; i < database.getRoadListSize() ; i++){
                // SET POINT RERENCE TO CURRENT INDEX
            curRoadPoints = database.getRoad(i).getRef();

            // ITERATE THROUGH ALL POINTS
            for(int j = 0 ; j < curRoadPoints.size() - 1 ; j++){
                    // GET THE OBJECT POINT FROM THE DATABASE
                    p =database.getPoint(curRoadPoints.get(j));
                    // GET THE SECOND POINT FROM THE DATABASE
                    p2 =database.getPoint(curRoadPoints.get(j+1));
                    // CONVERT TO JAVA XY
                    x1 = moveX(chX.Scale(p.getLongitude()));
                    // CONVERT TO JAVA XY
                    y1 = moveY(OperationY(chY.Scale(p.getLatitude())));
                    // CONVERT TO JAVA XY
                    x2 = moveX(chX.Scale(p2.getLongitude()));
                    // CONVERT TO JAVA XY
                    y2 = moveY(OperationY(chY.Scale(p2.getLatitude())));
                    // DRAW POINTS
                    pen.draw(new Line2D.Double(x1,y1,x2,y2)); 
            }                 
        }    
    }
   
    
//‘******************************************************
//‘*** Method Name: DrawCar
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: mehtod that draws car
//‘*** Method Inputs: none
//‘*** parameters: graphics g
//‘*** Return value: void
//‘******************************************************

    public void DrawCar(Graphics g)
    {
        // GREATE GRAPHICS 2D OBJECT
        Graphics2D g3 = (Graphics2D) g.create();
        // SET SOME PROPERTIES
        g3.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g3.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        // INIT X1
        double x1;
        // INIT Y1
        double y1;
        // INIT DIAMETER
        double d;
        // INIT RADIUS
        double r;
        // INIT THROUGH LIST OF CARS
        for(int i = 0; i < database.getVehicleListSize(); i++){
            // SET COLOR
            g3.setColor(Color.GREEN);
            // CONVERT X
            x1 = moveX(chX.Scale(database.getVehicle(i).getCorX()));
            // CONVERT Y
            y1 = moveY(OperationY(chY.Scale(database.getVehicle(i).getCorY())));
            // SET DIAMETER
            d = 4*scaler; 
            // SET RADIUS
            r = d/2;
            // DRAW CARS
            database.getVehicle(i).draw(g3, x1-r, y1-r, d, d,scaler);
        }
        
    }
    
//‘******************************************************
//‘*** Method Name: updateVehicles
//‘*** Method Author: Ali A
//‘******************************************************
//‘*** Purpose of the Method: updates cars
//‘*** Method Inputs: none
//‘*** parameters: none
//‘*** Return value: void
//‘******************************************************

    public void updateVehicles(int rate){
        // ITERATE THROUGH CAR LIST
        for(int i = 0; i < database.getVehicleListSize(); i++){
            // UPDATE TICKRATE
            database.getVehicle(i).move(rate);
        }
    }
    // THIS METHOD MAKES THE Y COORDINATE POSITIVE SINCE ITS NEGATIVE BY DEFAULT
    private double OperationY(double y){
        return -y + this.H;
    }
    // METHOD THAT'S PART OF THE CONVERSION EQUATION
    private double moveX(double x){
        // REUTNRS SCALED FACTORS
        return (x + moveX)*this.scaler;
    }
    // METHOD THAT'S PART OF THE CONVERSION EQUATION
    private double moveY(double y){
        // REUTNRS SCALED FACTORS
        return (y + moveY)*this.scaler;
    }
    
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // SET WIDTH
    public void setWidth(int width){
        this.W = width;
    }
    // SET HEIGHT
    public void setHeight(int height){
        this.H = height; 
    }
    // SET SCALE
    public void setScalar(double scale){
        this.scaler = scale;
    }    
    // SET SHIFTER
    public void setShiftXY(double moveX, double moveY){
        this.moveX = moveX;
        this.moveY = moveY;
    }
   
}


