package Storage;

import Cars.Car;
import Locations.School;
import OsmParser.PNode;
import OsmParser.NodeTable;
import OsmParser.Street;
import java.util.ArrayList;
//‘******************************************************
//‘*** Class Name: DB
//‘*** Class Author: Ali A
//‘******************************************************
//‘*** Purpose: this database class stores everything,
//‘*** roads, cars, nodes, speed, accident, you name it, we always retrieve
//‘*** stuff form this clas
//‘******************************************************
public class DB {
    //  INIT ALL ARRAYLISTS
    private static ArrayList<Car> carList;
    private static ArrayList<Street> roadList;
    private static ArrayList<School> schoolList;  
    // INIT NODE TABLE
    private static NodeTable nT;
    // INIT ACCIDENTS
    private static int numAccidents;
    // INIT BOUNDS
    private static double[] boundList;
    // CONSTRUCTOR
    public DB(){
        // SET ALL VALUES
        carList = new ArrayList();
        roadList = new ArrayList();
        schoolList = new ArrayList();
        boundList = new double[4];
        nT = new NodeTable();
        numAccidents = 0; 
    }
    
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // GETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public static ArrayList<Car> getVehicleList(){ return carList;} 
    public static ArrayList<Street> getRoadList(){return roadList;}   
    public static ArrayList<School> getSchoolList(){return schoolList;}
    public static NodeTable getnT(){return nT;}
    public int getNumAccident(){return numAccidents;}
    public static int getVehicleListSize(){return carList.size();}
    public static int getRoadListSize(){return roadList.size();}
    public static int getSchoolListSize(){return schoolList.size();}
    public static Street getRoad(int index){return roadList.get(index);}
    public static Car getVehicle(int index){return carList.get(index);}
    public static School getSchool(int index){return schoolList.get(index);}
    public static double getBounds(int index){return boundList[index];}
    public static PNode getPoint(String pointID){ return nT.getPoint(pointID);}
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    // SETTERS
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    public static void addVehicle(Car car){carList.add(car);}
    public static void addRoad(Street street){roadList.add(street);}
    public static void addPoint(PNode point){ nT.adder(point);}
    public static void addSchool(School school){ schoolList.add(school);}
    public static void setBounds( int index, double bound ){ boundList[index] = bound;}
    public void addAccident(){numAccidents++;}
    public void subAccident(){numAccidents--;}
}
